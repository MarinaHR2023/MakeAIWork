#!/usr/bin/env bash

# https://blog.logrocket.com/django-rest-framework-create-api/

echo "Update pip"
pip3 install --upgrade pip

echo "Install libraries with pip"
pip install -r requirements.txt